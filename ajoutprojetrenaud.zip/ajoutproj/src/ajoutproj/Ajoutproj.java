/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ajoutproj;

/**
 *
 * @author ZEIGE
 */
public class Ajoutproj {

    public void fsAps2adj(int[][] A, int[] fs, int[] aps) {
        int k = 1;
        int n = aps[0];
        int m = fs[0] - aps[0];
        A = new int[n + 1][];
        A[0] = new int[2];
        A[0][0] = n;
        A[0][1] = m;
        for (int i = 1; i <= n; i++) {
            A[i] = new int[n + 1];
            for (int j = 1; j <= n; j++) {
                if (A[i][j] == 1) {
                    fs[k] = j;
                    k++;
                } else {
                    fs[k] = 0;
                    k++;
                }
            }
        }

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }

}
