/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ajoutproj;

/**
 *
 * @author ZEIGE
 */
public class Ajoutproj {

    public class arete {

        int s, t;//extremité de l'arete
        float p;//poids de l'arete
    }

    public class graphe {

        int n;//nombre de sommets
        int m;//nombre d'arete
        arete[] a;//tableau d'arete
    }

    public void fsAps2adj(int[][] A, int[] fs, int[] aps) {
        int k = 1;
        int n = aps[0];
        int m = fs[0] - aps[0];
        A = new int[n + 1][];
        A[0] = new int[2];
        A[0][0] = n;
        A[0][1] = m;
        for (int i = 1; i <= n; i++) {
            A[i] = new int[n + 1];
            for (int j = 1; j <= n; j++) {
                if (A[i][j] == 1) {
                    fs[k] = j;
                    k++;
                } else {
                    fs[k] = 0;
                    k++;
                }
            }
        }
    }

    public void dist(int[] fs, int[] aps, int s, int[] tdist) {
        int t = 0;
        int d = 0;
        int p = 1, q = 1;
        int x;
        int[] fa = new int[aps[0] + 1];
        tdist = new int[aps[0] + 1];
        for (int i = 1; i <= aps[0]; ++i) {
            tdist[i] = -1;
        }
        tdist[s] = 0;
        fa[1] = s;
        while (t < q) {
            d++;
            for (int i = t + 1; i < q; i++) {
                x = fa[i];
                for (int j = aps[x]; fs[j] != 0; j++) {
                    if (tdist[fs[j]] == -1) {
                        tdist[fs[j]] = d;
                        fa[++p] = fs[j];
                    }
                }
            }
            t = q;
            q = p;
        }
    }

    public void ordonnancement(int[] fp, int[] app, int[] d, int[] lc, int[] fpc, int[] appc) {
        int n = app[0], kc = 1, t;
        lc = new int[n + 1];
        lc[0] = n;
        fpc = new int[fp[0] + 1];
        appc = new int[n + 1];
        appc[0] = n;
        lc[1] = 0;
        fpc[1] = 0;
        appc[1] = 1;
        for (int s = 2; s <= n; ++s) {
            lc[s] = 0;
            appc[s] = kc + 1;
            for (int k = app[s]; (t = fp[k]) != 0; ++k) {
                int v = lc[t] + d[t];
                if (v >= lc[s]) {
                    if (v > lc[s]) {
                        kc = appc[s];
                        fpc[kc] = t;
                    } else {
                        kc++;
                        fpc[kc] = t;
                    }
                }
            }
            kc++;
            fpc[kc] = 0;
        }
        fpc[0] = kc;
    }
    
    void Prufer(int[] t)
{

    int[] cpt=new int[t[0]+3];
    boolean[] I= new boolean [t[0]+3];
    for(int i=1;i<t[0]+2;++i)
    {
        I[i]=true;
        cpt[i]=0;
    }
    for(int i=1;i<t[0]+1;++i)
    {
        cpt[t[i]]++;
    }
    for(int i=1;i<t[0]+1;++i)
    {
        int j=1;
        while(!I[j]||cpt[j]>0)
        {
            ++j;
        }

        System.out.println("[ "+t[i]+" , "+j+" ]");
        I[j]=false;
        cpt[t[i]]--;
    }
    int j=1;
    while(I[j])
        j++;
    System.out.println("[ "+j+" , ");
    j++;
    while(!I[j])
        j++;
    System.out.println(j+" ]");
    
}

void cod_prufer(int[][] A,int[] t)
{
    int n=A[0][0]-2;
     t=new int [n+1];
    t[0]=n;
    int cpt;
    for(int i=1;i<=n+2;++i)
    {
        cpt=0;
        for(int j=1;j<=n+2;++j)
        {
            if(A[i][j]==1)
            {
                cpt++;
            }
        }
        A[i][0]=cpt;
    }
    int i,j;
    for(int k=1;k<=n;++k)
    {
        i=1;
        while(A[i][0]!=1)
            ++i;
        j=1;
        while(A[i][j]!=1)
            ++j;
        t[k]=j;
        A[i][0]=0;
        A[j][0]--;
        A[i][j]=0;
        A[j][i]=0;
    }

}
    
    public void fusion(int i, int j, int[] prem, int[] pilch, int[] cfc) {

        int s = prem[i];
        cfc[s] = j;
        while (pilch[s] != 0) {
            s = pilch[s];
            cfc[s] = j;
        }
        pilch[s] = prem[j];
        prem[j] = prem[i];
    }

    public void Kruskal(graphe g, graphe h) {
        int[] prem = new int[g.n + 1];
        int[] pilch = new int[g.n + 1];
        int[] cfc = new int[g.n + 1];
        for (int i = 1; i <= g.n; ++i) {
            prem[i] = i;
            pilch[i] = 0;
            cfc[i] = i;
        }
        h.n = g.n;
        h.m = h.n - 1;
        h.a = new arete[h.n - 1];
        int i, j;
        for (i = 0, j = 0; j < h.m; ++i) {
            arete e = g.a[i];
            if (cfc[e.s] != cfc[e.t]) {
                h.a[j++] = e;
                fusion(cfc[e.s], cfc[e.t], prem, pilch, cfc);
            }
        }
    }
}
